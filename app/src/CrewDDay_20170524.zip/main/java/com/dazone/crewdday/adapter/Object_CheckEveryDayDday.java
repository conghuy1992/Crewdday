package com.dazone.crewdday.adapter;

/**
 * Created by maidinh on 16/5/2016.
 */
public class Object_CheckEveryDayDday {
    public String TypeName;
    public String StartDate;
    public String EndDate;
    public int Interval;
    public String StartOption;
    public int HolidayCondition;

    public String getTypeName() {
        return TypeName;
    }

    public void setTypeName(String typeName) {
        TypeName = typeName;
    }

    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String startDate) {
        StartDate = startDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String endDate) {
        EndDate = endDate;
    }

    public int getInterval() {
        return Interval;
    }

    public void setInterval(int interval) {
        Interval = interval;
    }

    public String getStartOption() {
        return StartOption;
    }

    public void setStartOption(String startOption) {
        StartOption = startOption;
    }

    public int getHolidayCondition() {
        return HolidayCondition;
    }

    public void setHolidayCondition(int holidayCondition) {
        HolidayCondition = holidayCondition;
    }
}
