package com.dazone.crewdday.mInterface;

public interface ConnectionFailedCallback {
    void onConnectionFailed();
}