package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 17/5/2016.
 */
public interface DeleteSuccess {
    void onDeleteSuccess();
}
