package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 25/7/2016.
 */
public interface IFRepetitionString {
    void onGetRepetitionStringSuccess(String str);
}
