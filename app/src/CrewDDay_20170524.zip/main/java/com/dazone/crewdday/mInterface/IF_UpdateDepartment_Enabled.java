package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 3/8/2016.
 */
public interface IF_UpdateDepartment_Enabled {
    void onSuccess();
    void onFail();
}
