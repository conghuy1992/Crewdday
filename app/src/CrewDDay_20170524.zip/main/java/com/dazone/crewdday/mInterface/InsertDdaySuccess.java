package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 5/5/2016.
 */
public interface InsertDdaySuccess {
    void onInsertSuccess();
}
