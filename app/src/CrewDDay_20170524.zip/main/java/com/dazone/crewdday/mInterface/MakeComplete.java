package com.dazone.crewdday.mInterface;

public interface MakeComplete {
    void onSuccessMakeComplete(long dataNo);
}
