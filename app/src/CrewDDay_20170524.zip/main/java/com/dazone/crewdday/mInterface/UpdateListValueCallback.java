package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 31/03/16.
 */
public interface UpdateListValueCallback {
    void updateValue(String text,int position,int type);
}
