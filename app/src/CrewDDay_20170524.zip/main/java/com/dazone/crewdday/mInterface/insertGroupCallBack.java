package com.dazone.crewdday.mInterface;

public interface insertGroupCallBack {
    void onSuccess(long groupNo);
}