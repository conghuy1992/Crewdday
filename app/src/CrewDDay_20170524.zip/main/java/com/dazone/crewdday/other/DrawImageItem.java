package com.dazone.crewdday.other;

/**
 * Created by david on 12/25/15.
 */
public interface DrawImageItem {
    String getImageLink();
    String getImageTitle();
}
