package com.dazone.crewdday.other;


/**
 * Created by Sherry on 12/31/15.
 */
public interface OnOrganizationSelectedEvent {
    void onOrganizationCheck(boolean isCheck, PersonData personData);
}
