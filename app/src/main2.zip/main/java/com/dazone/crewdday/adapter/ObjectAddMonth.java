package com.dazone.crewdday.adapter;

/**
 * Created by maidinh on 12/5/2016.
 */
public class ObjectAddMonth {
    int id;
    int date;
    int week;
    int day_of_week;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public int getWeek() {
        return week;
    }

    public void setWeek(int week) {
        this.week = week;
    }

    public int getDay_of_week() {
        return day_of_week;
    }

    public void setDay_of_week(int day_of_week) {
        this.day_of_week = day_of_week;
    }
}
