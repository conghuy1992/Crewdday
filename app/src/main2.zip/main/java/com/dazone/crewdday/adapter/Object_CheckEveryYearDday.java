package com.dazone.crewdday.adapter;

/**
 * Created by maidinh on 16/5/2016.
 */
public class Object_CheckEveryYearDday {
    public String TypeName;
    public String StartDate;
    public String EndDate;
    public int Interval;
    public String SpecificMMDD;
    public String SpecificMMnthWeek;
    public int Lunar;
    public int HolidayCondition;

}
