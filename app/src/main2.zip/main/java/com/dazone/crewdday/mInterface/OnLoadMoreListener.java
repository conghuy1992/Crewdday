package com.dazone.crewdday.mInterface;

public interface OnLoadMoreListener {
    void onLoadMore();
}