package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 23/03/16.
 */
public interface ShowButtonAddCallback {
    void showButtonAdd();
}
