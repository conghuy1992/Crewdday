package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 13/6/2016.
 */
public interface UpdateGroupCalllback {
    void onUpdateSuccess();
}
