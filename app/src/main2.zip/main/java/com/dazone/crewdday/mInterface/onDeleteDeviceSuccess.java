package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 30/5/2016.
 */
public interface onDeleteDeviceSuccess {
    void DeleteSuccess();
}
