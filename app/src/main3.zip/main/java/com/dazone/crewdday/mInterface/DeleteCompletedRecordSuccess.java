package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 15/6/2016.
 */
public interface DeleteCompletedRecordSuccess {
    void onDeleteCompletedRecordSuccess();
}
