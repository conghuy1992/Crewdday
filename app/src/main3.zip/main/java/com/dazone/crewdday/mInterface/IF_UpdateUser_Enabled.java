package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 27/12/2016.
 */

public interface IF_UpdateUser_Enabled {
    void onSuccess();
    void onFail();
}
