package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 15/03/16.
 */
public interface ManageTabFragments {
    void loadFragment();
}
