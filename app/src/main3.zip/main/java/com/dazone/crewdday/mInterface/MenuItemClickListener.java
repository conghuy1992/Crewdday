package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 02/03/16.
 */
public interface MenuItemClickListener {
    void onClick(int position,boolean isLongClick);
}
