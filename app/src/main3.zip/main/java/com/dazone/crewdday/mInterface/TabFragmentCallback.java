package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 16/03/16.
 */
public interface TabFragmentCallback {
    void checkListNull(String type,boolean result);
}
