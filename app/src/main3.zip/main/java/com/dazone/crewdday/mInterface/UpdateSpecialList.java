package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 06/04/16.
 */
public interface UpdateSpecialList {
    void updateSpecialList();
    void updateItemInList();
}
