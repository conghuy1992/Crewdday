package com.dazone.crewdday.other;

import java.util.Calendar;

/**
 * Created by david on 5/20/15.
 */
public interface DatePickerFragmentDialogListener {
    void onFinishEditDialog(Calendar mDate);
}
