package com.dazone.crewdday.adapter;

/**
 * Created by maidinh on 16/5/2016.
 */
public class Object_CheckEveryMonthSpecificDday {
    public String TypeName;
    public String StartDate;
    public String EndDate;
    public int Interval;
    public String SpecificDD;
    public String SpecificWeek;
    public int HolidayCondition;
}
