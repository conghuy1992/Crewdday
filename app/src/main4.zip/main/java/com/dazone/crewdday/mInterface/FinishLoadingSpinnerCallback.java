package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 29/03/16.
 */
public interface FinishLoadingSpinnerCallback {
    void finishLoadSpinner();
}
