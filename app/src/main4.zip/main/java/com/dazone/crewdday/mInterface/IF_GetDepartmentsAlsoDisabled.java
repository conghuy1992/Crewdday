package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 2/8/2016.
 */
public interface IF_GetDepartmentsAlsoDisabled {
    void onSuccess();
    void onFail();
}
