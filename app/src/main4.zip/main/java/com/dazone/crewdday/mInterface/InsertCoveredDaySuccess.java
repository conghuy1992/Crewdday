package com.dazone.crewdday.mInterface;

public interface InsertCoveredDaySuccess {
    void onInsertCoveredDaySuccess(long dataNo);
}
