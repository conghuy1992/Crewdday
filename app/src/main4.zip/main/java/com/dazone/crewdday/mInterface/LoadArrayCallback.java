package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 14/03/16.
 */
public interface LoadArrayCallback {
    void loadArrayCallBack(String[] array);
}
