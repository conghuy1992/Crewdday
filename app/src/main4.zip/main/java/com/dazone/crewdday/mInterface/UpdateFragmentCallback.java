package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 05/04/16.
 */
public interface UpdateFragmentCallback {
    void updateFragment();
}
