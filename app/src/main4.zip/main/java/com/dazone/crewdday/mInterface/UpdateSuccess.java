package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 6/5/2016.
 */
public interface UpdateSuccess {
    void onUpdateSuccess();
}
