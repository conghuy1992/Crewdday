package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 15/7/2016.
 */
public interface onGetCountOfUnreadedDdays {
    void onGetCountOfUnreadedDdaysSuccess(int number);
    void onFail();
}
