package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 27/7/2016.
 */
public interface updateGroupNameCallBack {
    void onSuccess();
}
