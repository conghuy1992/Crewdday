package com.dazone.crewdday.adapter;

/**
 * Created by maidinh on 16/5/2016.
 */
public class Object_CheckDPlusDay {
    String TypeName="CheckDPlusDay";
    String StartDate;
    int Lunar;

    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String startDate) {
        StartDate = startDate;
    }

    public int getLunar() {
        return Lunar;
    }

    public void setLunar(int lunar) {
        Lunar = lunar;
    }
}
