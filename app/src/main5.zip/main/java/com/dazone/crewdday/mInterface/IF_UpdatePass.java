package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 5/22/2017.
 */

public interface IF_UpdatePass {
    void onSuccess(String newSessionID);
    void onFail();
}