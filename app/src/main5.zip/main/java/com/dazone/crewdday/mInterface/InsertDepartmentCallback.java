package com.dazone.crewdday.mInterface;

/**
 * Created by maidinh on 1/8/2016.
 */
public interface InsertDepartmentCallback {
    void onInsertDepartmentSuccess();
    void Fail();
}
