package com.dazone.crewdday.mInterface;

public interface LoginSuccessCallback {
    void onLoginSuccessCallback(String str);
    void onLoginFailedCallback();
}
