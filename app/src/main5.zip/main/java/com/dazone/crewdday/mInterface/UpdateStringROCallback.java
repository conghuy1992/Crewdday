package com.dazone.crewdday.mInterface;

/**
 * Created by DAZONE on 28/03/16.
 */
public interface UpdateStringROCallback {
    void updateStringBuilder(StringBuilder stringBuilder);
    void updateStringBuilder(String string,int type);
}
