package com.dazone.crewdday.model;

/**
 * Created by DAZONE on 14/04/16.
 */
public class DailyDDay extends BaseDDay {
    private String startOption;

    public String getStartOption() {
        return startOption;
    }

    public void setStartOption(String startOption) {
        this.startOption = startOption;
    }
}
