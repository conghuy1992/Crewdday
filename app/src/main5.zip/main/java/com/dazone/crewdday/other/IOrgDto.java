package com.dazone.crewdday.other;

/**
 * Created by david on 12/25/15.
 */
public interface IOrgDto {
    String getName();
    int getNo();
}
