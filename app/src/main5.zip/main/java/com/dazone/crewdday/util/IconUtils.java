package com.dazone.crewdday.util;

import com.dazone.crewdday.R;

public class IconUtils {

    public static int getFlagDrawableId(int tag){
        int flagId = 0;
        switch (tag){
            case 0:
                flagId = R.drawable.tag_icon_01;
                break;
            case 1:
                flagId = R.drawable.tag_icon_02;
                break;
            case 2:
                flagId = R.drawable.tag_icon_03;
                break;
            case 3:
                flagId = R.drawable.tag_icon_04;
                break;
            case 4:
                flagId = R.drawable.tag_icon_05;
                break;
            case 5:
                flagId = R.drawable.tag_icon_06;
                break;
            case 6:
                flagId = R.drawable.tag_icon_07;
                break;
            case 7:
                flagId = R.drawable.tag_icon_08;
                break;
            case 8:
                flagId = R.drawable.tag_icon_09;
                break;
            case 9:
                flagId = R.drawable.tag_icon_10;
                break;
            case 10:
                flagId = R.drawable.tag_icon_11;
                break;
            case 11:
                flagId = R.drawable.tag_icon_12;
                break;
            case 12:
                flagId = R.drawable.tag_icon_13;
                break;
            case 13:
                flagId = R.drawable.tag_icon_14;
                break;
            case 14:
                flagId = R.drawable.tag_icon_15;
                break;
            case 15:
                flagId = R.drawable.tag_icon_16;
                break;
            case 16:
                flagId = R.drawable.tag_icon_17;
                break;
            case 17:
                flagId = R.drawable.tag_icon_18;
                break;
            case 18:
                flagId = R.drawable.tag_icon_19;
                break;
            case 19:
                flagId = R.drawable.tag_icon_20;
                break;
            case 20:
                flagId = R.drawable.tag_icon_21;
                break;
            case 21:
                flagId = R.drawable.tag_icon_22;
                break;
            case 22:
                flagId = R.drawable.tag_icon_23;
                break;
            case 23:
                flagId = R.drawable.tag_icon_24;
                break;
            case 24:
                flagId = R.drawable.tag_icon_25;
                break;
            case 25:
                flagId = R.drawable.tag_icon_26;
                break;
            case 26:
                flagId = R.drawable.tag_icon_27;
                break;
            case 27:
                flagId = R.drawable.tag_icon_28;
                break;
            case 28:
                flagId = R.drawable.tag_icon_29;
                break;
            case 29:
                flagId = R.drawable.tag_icon_30;
                break;
            case 30:
                flagId = R.drawable.tag_icon_31;
                break;

            default:

                break;

        }


        return flagId;

    }
}
